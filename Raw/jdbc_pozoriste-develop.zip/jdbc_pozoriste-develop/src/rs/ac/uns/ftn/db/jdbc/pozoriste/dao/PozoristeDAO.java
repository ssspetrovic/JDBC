package rs.ac.uns.ftn.db.jdbc.pozoriste.dao;

import rs.ac.uns.ftn.db.jdbc.pozoriste.model.Pozoriste;

public interface PozoristeDAO extends CRUDDao<Pozoriste, Integer> {}
