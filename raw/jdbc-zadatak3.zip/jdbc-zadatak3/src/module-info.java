module JDBC_Zadatak3 {
    requires java.sql;
    requires HikariCP.java7;
    requires slf4j.api;
    requires slf4j.simple;
    requires ojdbc6;
}