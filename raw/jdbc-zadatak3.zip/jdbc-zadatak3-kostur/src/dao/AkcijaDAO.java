package dao;

import model.Akcija;

public interface AkcijaDAO extends CRUDDao<Akcija, Integer> {

}
